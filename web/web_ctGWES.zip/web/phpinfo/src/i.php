<?php
include 'flag.php';
putenv("YOUR-FLAG-IS=$flag");
phpinfo();
?>
