#!/bin/bash
# echo $1>/flag.txt && chmod 777 /flag.txt
echo "<?php">/var/www/html/flag.php && echo '$flag = "'$1'";'>>/var/www/html/flag.php && echo "?>">>/var/www/html/flag.php

