<?php
/*
 * File Name: flag.php
 * Author: Image
*/
$flag="flag{ph4nt0mj5_lfI}";
?>
