<?php
header("Content-Type: text/html;charset=utf-8");
include("flag.php");
$url = "http://qr.topscan.com/api.php?text=".$flag;
$flags = file_get_contents($url);
$erweima = "data:image/png;base64,".base64_encode($flags);
?>
<p style="text-align:center;"><br /></p>
<p style="text-align:center;"><br /></p>
<p style="text-align:center;"><span style="font-size:18px;">这题 需要一个智能手机</span></p>
<p style="text-align:center;">
	<span style="font-size:18px;">下面是个假的FLAG 不信你扫扫看</span><span style="font-size:18px;"></span>
</p>
<p style="text-align:center;">
	<span style="font-size:18px;"><img src="<?php echo $erweima;?>" title="Flag{W0_sH1_JI0_ed}" alt="Flag{W0_sH1_JI0_ed}" /><br />
</span>
</p>
