<?php
header("content-type:text/html;charset=utf-8");
        if ($_POST['user_name']=='admin' and $_POST['user_pwd']=='723d505516e0c197e42a6be3c0af910e')
                {
                   echo "登录成功，但是flag不在这里哦，试试phpmyadmin.php";
                }
        else
        {
                echo '密码错误!';
        }
?>
