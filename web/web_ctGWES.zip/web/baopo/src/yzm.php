<?php
header("content-type:text/html;charset=utf-8");
	if ($_POST['yzm']=='ODE3OTkx')
		{
			echo '你的密码是723d505516e0c197e42a6be3c0af910e';
		}
	else
	{
		echo '验证码错误!';
	}
?>
