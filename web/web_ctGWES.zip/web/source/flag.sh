#!/bin/bash
echo $1>/flag.txt
chmod 777 /flag.txt
