<?php

function show_flag(){

	$flag='[d0cb52940652171fc01a7639aa7285537f13ad97.php]';

	echo $flag;

}
