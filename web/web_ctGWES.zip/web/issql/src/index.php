<html xmlns="http://www.w3.org/1999/xhtml">
<!--This set of source code is made by MS. -->
<!--Date 2018.12.13-->
	<head>
		<meta http-equiv=Content-Type content="text/html;charset=utf-8">
		<meta name="description" content="Test">
		<meta name="author" content="MRYE+">
		<title>电脑信息查询 - 网络安全工作室</title>
		<link rel="stylesheet" type="text/css" href="./css/ctf.css" />	
    </style>
</head>
<body>
<div class="container">
  <div id="search">
    <label for="search">输入以1、2、3显示电脑信息</label>
	<form id="myForm" action="" method="post">
    <input type="text" id="ms" name="ms"maxlength="1">
    <input class="button" type="submit" value="Search">
	</form>
<?php
//禁用错误报告
error_reporting(0);
header("Content-Type: text/html;charset=utf-8");
require_once './suxinctf.php';

if(isset($_POST["ms"]))
{
	$ID = $_POST["ms"];
	#echo $ID;
	$query = "select * from goods where id='{$ID}'";//构建查询语句
	$result = mysql_query($query);//执行查询
	if (!$result) {
		die("could not to the database\n" . mysql_error());
	}
	if (mysql_numrows($result)<=0) {
		echo "<script 	type='text/javascript'>alert('都说了让你输入1~3你咋还那么调皮！');location.href='index.php'</script>";
	}else{
	while($result_row=mysql_fetch_row(($result)))//取出结果并显示
	{
		$ms=$result_row[0];
		$gname=$result_row[1];
		$gprice=$result_row[2];
		$gnum=$result_row[3];
		echo "<font color='red'>电脑编号为：".$ms."　　</font> ";;
		echo "<font color='red'>电脑系统为：".$gname."　　</font>";
		echo "<font color='red'>电脑价格为：".$gprice."　　</font>";
		echo "<font color='red'>电脑数量为：".$gnum."　　</font>";
}
}
}
	$query = "select * from goods ";//构建查询语句
	$result = mysql_query($query);//执行查询
	if (!$result) {
		die("could not to the database\n" . mysql_error());
	}
	if (mysql_numrows($result)<=0) {
		echo "<script 	type='text/javascript'>alert('都说了让你输入1~3你咋还那么调皮！');location.href='index.php'</script>";
	}else{
	while($result_row=mysql_fetch_row(($result)))//取出结果并显示
	{
		$ms=$result_row[0];
		$gname=$result_row[1];
	}

mysql_close($connection);//关闭连接
}
?>
  </div>
</div>
</body>
</html>
