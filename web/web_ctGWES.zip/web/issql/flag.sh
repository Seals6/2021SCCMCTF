#!/bin/bash
sed -i 's/flag{123}/'$1'/g' /tmp/ctf.sql
sleep 3
mysql</tmp/ctf.sql 
