<?php
#error_reporting(0);
?>
<html lang="zh-CN">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width  minimum-scale=1.0  maximum-scale=1.0  initial-scale=1.0" />
    <title>This Is BaseWeb</title>
</head>
<body>
    <center>
    <h4>where is the flag?</h4>
    </center>
    <!-- hint:?ti0s= -->
    <?php
        if(isset($_GET['ti0s'])){
            $ti0s=$_GET['ti0s'];
            highlight_file(__FILE__);
            if(preg_match("/[A-Za-oq-z0-9$]+/",$ti0s)){
            
                die("No.1 Die");
            }
            if(preg_match("/\~|\!|\@|\#|\%|\^|\&|\*|\(|\)|\（|\）|\-|\_|\{|\}|\[|\]|\'|\"|\:|\,/",$ti0s)){
                die("No.2 Die");
            }
            eval($ti0s);
        
        }
    
     ?>

</body>
</html>

