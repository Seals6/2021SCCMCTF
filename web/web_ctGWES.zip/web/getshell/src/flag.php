<?php
/*
 * File Name: flag.php
*/
$flag="flag{getshell_without_letters}";
?>
&lt;?php<br/>
$flag="flag{this_is_not_real_flag}";
